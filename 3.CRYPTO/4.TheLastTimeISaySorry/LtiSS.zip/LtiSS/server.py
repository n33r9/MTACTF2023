#!/usr/bin/env python3

import base64
import hashlib
import hmac
from io import BytesIO, StringIO
import random
import string
import time
from Crypto.Util.number import long_to_bytes
from socketssl import encrypt, decrypt

FLAG = open("FLAG", "rb").read()
assert len(FLAG) == 16
def generate_key():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=10)).encode()


class Challenge():
    def __init__(self):
        self.before_input = "Token generate!" 
        self.key = generate_key()
        self.option = '''1. Generate
2. Decrypt
3. Exit'''
    def run(self):
        while(1):
            try:
                print(self.option)
                option = int(input("Option: "))
                if option == 1:
                    data_prefix =  input("Prefix: ")
                    data_suffix =  input("Suffix: ")
                    def remove_special(string):
                        return ''.join(e for e in string if e.isalnum()).encode('cp037')
                    data = remove_special(data_prefix ) + FLAG +  remove_special(data_suffix)
                    output = self.encrypt(data)
                    print("Output: ", output)
                elif option == 2:
                    data =  input("Data: ")
                    data =  base64.b64decode(data)
                    try:
                        out = self.decrypt(data)
                        if FLAG in out:
                            print("Success")
                        else:
                            print("Fail")
                    except Exception as e:
                        print("Error", e)
                elif option == 3:
                    break

            except Exception as e:
                print("Have a error!!")
            
    def decrypt(self, data):
        stream_input = BytesIO(data)
        stream_output = BytesIO(b"")
        decrypt(stream_input, stream_output, self.key)
        stream_output.seek(0)
        output = stream_output.read()
        
        output, mac = [output[:-32], output[-32:]]
        mac_cal = hmac.new(self.key, output, hashlib.sha256).digest()
        if mac != mac_cal:
            raise Exception("Error mac")
        return output
    def encrypt(self, data):
        return encrypt(data, self.key)

try:
    chal = Challenge()
    print(chal.before_input)
    chal.run()
except:
    print("Have a error!!")

