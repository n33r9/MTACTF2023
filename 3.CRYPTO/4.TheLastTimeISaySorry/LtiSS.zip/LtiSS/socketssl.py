#https://stackoverflow.com/questions/16761458/how-to-decrypt-openssl-aes-encrypted-files-in-python
from hashlib import md5
import hashlib
import hmac
import os
import random
import string
from Crypto.Cipher import AES
from Crypto import Random

def derive_key_and_iv(password, salt, key_length, iv_length):
    d = d_i = b''
    while len(d) < key_length + iv_length:
        d_i =  md5(d_i + password + salt).digest()
        d += d_i
    return d[:key_length], d[key_length:key_length+iv_length]

def decrypt(in_file, out_file, password, key_length=32):
    bs = AES.block_size
    salt = in_file.read(bs)[len('Salted__'):]
    key, iv = derive_key_and_iv(password, salt, key_length, bs)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    next_chunk = b''
    finished = False
    while not finished:
        chunk, next_chunk = next_chunk, cipher.decrypt(in_file.read(1024 * bs))
        if len(next_chunk) == 0:
            padding_length = chunk[-1]
            chunk = chunk[:-padding_length]
            finished = True
        out_file.write(chunk)

def encrypt(input_string, password):
    file_in = "/tmp/" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
    file_out = file_in + ".enc"
    mac = hmac.new(password, input_string, hashlib.sha256)
    input_string = input_string + mac.digest()
    password = password.decode("utf-8")
    with open(file_in, "wb") as f:
        f.write(input_string)
        f.close()
    
    
    os.system(f"openssl aes-256-cbc -salt -base64 -in {file_in} -out {file_out} -md md5 -pass pass:{password} > /dev/null 2>&1")
    
    with open(file_out, "r") as f:
        a =  f.read().replace("\n", "")
        return  a
    #